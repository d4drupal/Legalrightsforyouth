(function ($, Drupal) {
  Drupal.behaviors.customCheckboxClasses = {
    attach: function (context, settings) {      

      $("#node-article-form .field--name-field-tags .form-type--checkbox, #node-article-edit-form .field--name-field-tags .form-type--checkbox", context).each(function () {
        var labelText = $(this).text().trim(); // Get the text of the label

        if (labelText.startsWith("-")) {
          $(this).addClass("child-class"); // Add child class
        } else {
          $(this).closest(".field--name-field-tags .form-type--checkbox").addClass("parent-class"); // Add parent class
        }
      });

      // Wrap child checkboxes inside a main div (child-container)
      $(".parent-class").each(function () {
        var $parent = $(this);
        var $children = $parent.nextUntil(".parent-class", ".child-class");

        if ($children.length) {
          $children.wrapAll('<div class="child-container" style="display: none;"></div>');
          // Add a toggle icon next to parent-class
          $parent.append('<span class="toggle-icon">+</span>');
        }
      });

      // **Ensure parent remains open if any child is checked**
      $(".child-container").each(function () {
        var $childContainer = $(this);
        if ($childContainer.find(".field--name-field-tags input[type='checkbox']:checked").length) {
          $childContainer.show();
          $childContainer.prev(".parent-class").find(".toggle-icon").text("-");
        }
      });

      // Toggle child-container when clicking anywhere on .parent-class
      $(".parent-class").on("click", function (e) {
        // Prevent toggling when clicking on checkboxes
        if ($(e.target).is(".field--name-field-tags input[type='checkbox']")) return;

        var $parent = $(this);
        var $childContainer = $parent.next(".child-container");
        var $icon = $parent.find(".toggle-icon");

        if ($childContainer.is(":visible")) {
          $childContainer.slideUp();
          $icon.text("+");
        } else {
          $(".child-container").slideUp();
          $(".toggle-icon").text("+");

          $childContainer.slideDown();
          $icon.text("-");
        }
      });

      // **Ensure parent-class stays open when a child is checked**
      $(".child-class input[type='checkbox']").on("change", function () {
        var $childContainer = $(this).closest(".child-container");
        var $parent = $childContainer.prev(".parent-class");
        var $icon = $parent.find(".toggle-icon");

        if ($childContainer.find(".field--name-field-tags input[type='checkbox']:checked").length) {
          $childContainer.slideDown();
          $icon.text("-");
        } else {
          $childContainer.slideUp();
          $icon.text("+");
        }
      });
    }
  };
})(jQuery, Drupal);
