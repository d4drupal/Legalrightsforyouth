(function (Drupal, drupalSettings) {
    Drupal.behaviors.legalRightsForYouth = {
        attach: function (context, settings) {
            if (!drupalSettings.legalRightsForYouth) {
                console.warn("drupalSettings.legalRightsForYouth is undefined.");
                return;
            }
            let total = drupalSettings.legalRightsForYouth.total || 0;
  
            if (window.location.pathname.includes("/search/node")) {
                const results = document.querySelectorAll(".search-result__title");
                const blockContent = document.querySelector("#block-legalrightsforyouth-content h2");
        
                if (blockContent) {
                    blockContent.textContent = `Search results (${total})`;
                }

                const hiddenInfo = document.querySelectorAll(".search-result__info");
                hiddenInfo.forEach(info => {
                    info.remove(); // Completely removes the element from the DOM
                });

                const hiddensearchform = document.querySelectorAll(".search-form");
                hiddensearchform.forEach(info => {
                    info.remove(); // Completely removes the element from the DOM
                });
            }

            function moveHeader() {
                $('.view-topic-search .view-header').insertBefore('.view-topic-search .view-content');
            }
        
            // Run on document ready
            $(document).ready(function () {
                moveHeader();
            });
        
            // Re-run after AJAX calls
            $(document).ajaxSuccess(function () {
                moveHeader();
            });
        }
    };
})(Drupal, drupalSettings);


document.addEventListener('DOMContentLoaded', function() {
    const mobileMenu = document.querySelector('.mobile-navigation');
    const menuToggle = document.querySelector('.toggle-expand');
    menuToggle.addEventListener('click', function() {
        mobileMenu.classList.toggle('expanded');
        menuToggle.classList.toggle('expanded');
        document.body.classList.toggle('no-scroll');
    })

    // Search toggle
    const searchToggle = document.querySelector('.region-main-navigation form input[type="submit"]');
    const searchForm = document.querySelector('.region-main-navigation form');
    searchToggle.addEventListener('click', function(e) {
        if(!searchForm.classList.contains('expanded')) {
            e.preventDefault();
            searchForm.classList.add('expanded');
        }
    });

    // Topic menu active
    const topicMenu = document.querySelectorAll('.view-header-topic-menu .topic-item');
    if(topicMenu.length > 0) {
        const currentPath = window.location.pathname;
        topicMenu.forEach((topic) => {
            if(topic.getAttribute('href') == currentPath) {
                topic.classList.add('active');
            }
        })
    }
});
    

jQuery(document).ready(function() {  
   
        function moveHeader() {
            jQuery('.view-topic-search .view-header').insertBefore('.view-topic-search .view-content');
            
        }
    
        moveHeader(); // Run on page load
    
        jQuery(document).ajaxSuccess(function() {
            moveHeader(); // Run after AJAX updates
        });
    

    function updateSelectedOptions(form) {
        var selectedOptions = [];
        
        // Collect checked checkboxes within the current form
        form.find('.form-checkbox:checked').each(function () {
            var labelText = jQuery('label[for="' + jQuery(this).attr('id') + '"]').text();
            selectedOptions.push(labelText);
        });

        // Remove existing <h2> before updating
        form.find('.selected-options-header').remove();

        // If there are selected options, add them inside a single <h2>
        if (selectedOptions.length > 0) {
            var header = jQuery('<h2 class="selected-options-header">' + selectedOptions.join(', ') + '</h2>');

            // Prepend the header before .bef-nested
            form.find('.bef-nested').first().before(header);
        }
    }

    // Detect checkbox changes within any matching form
    jQuery(document).on('change', '.form-checkbox', function () {
        var form = jQuery(this).closest('[id^="views-exposed-form-explore-listing-by-category-page-"]');
        updateSelectedOptions(form);
    });

    // Restore checked options after AJAX refresh
    jQuery(document).ajaxComplete(function () {
        jQuery('[id^="views-exposed-form-explore-listing-by-category-page-"]').each(function () {
            updateSelectedOptions(jQuery(this));
        });
    });

    // Initialize selected options on page load
    jQuery('[id^="views-exposed-form-explore-listing-by-category-page-"]').each(function () {
        updateSelectedOptions(jQuery(this));
    });
});

