document.addEventListener("DOMContentLoaded", function () {
    const thumbnail = document.querySelector(".article-page-thumbnail-image");
    const videoContainer = document.getElementById("videoPlayer");

    let modal = document.createElement("div");
    modal.id = "videoModal";
    modal.style.display = "none"; // Hide initially
    modal.innerHTML = `
        <div class="modal-overlay">
            <div class="modal-content">
                <span id="closeModal">&times;</span>
                <iframe id="modalVideo" width="640" height="480" frameborder="0" allow="autoplay; fullscreen; encrypted-media" allowfullscreen></iframe>
            </div>
        </div>
    `;
    document.body.appendChild(modal);

    const modalVideo = document.getElementById("modalVideo");
    const closeModal = document.getElementById("closeModal");

    if (thumbnail && videoContainer) {
        let iframe = videoContainer.querySelector("iframe");

        if (iframe) {
            let videoSrc = iframe.getAttribute("src");
            let autoplaySrc = videoSrc.includes("?") ? `${videoSrc}&autoplay=1` : `${videoSrc}?autoplay=1&muted=2`;

            // Preload the video source for faster loading
            modalVideo.src = autoplaySrc;
            modalVideo.loading = "lazy";
        }

        thumbnail.addEventListener("click", function () {
            modal.style.display = "block"; // Show modal instantly
        });

        closeModal.addEventListener("click", function () {
            modal.style.display = "none";
        });
    }
});  



(function ($, Drupal, drupalSettings) {
    Drupal.behaviors.showMoreToggle = {
        attach: function (context, settings) {
            let ulElement = $(".view-topic-search .bef-nested", context);
            if (!ulElement.length) return; // Ensure the element exists

            let listItems = ulElement.find("li");

            // Remove existing button before appending a new one (to prevent duplicates)
            $("#toggleBtn").remove();

            // Create "Show All +" button
            let btn = $('<button>', {
                id: "toggleBtn",
                class: "show-more-btn",
                text: "Show All +",
                type: "button"
            });

            ulElement.after(btn); // Insert button after <ul>

            // Initially hide all items after 10
            listItems.slice(10).hide();

            // Show button only if more than 10 items exist
            if (listItems.length > 10) {
                btn.show();
            }

            let allItemsVisible = false; // Track expanded state
            let liClicked = false; // Track if an <li> was clicked

            // Toggle button functionality
            btn.off("click").on("click", function (event) {
                event.preventDefault(); // Prevent page reload

                if (!allItemsVisible) {
                    listItems.fadeIn(300); // Show all items
                    $(this).text("Show Less -");
                    allItemsVisible = true;
                } else {
                    if (!liClicked) {
                        // Hide extra items only if no li was clicked
                        listItems.slice(10).fadeOut(300);
                        $(this).text("Show All +");
                        allItemsVisible = false;
                    }
                }
            });

            // If an <li> is clicked, disable "Show Less -"
            listItems.off("click").on("click", function () {
                liClicked = true; // Set flag when <li> is clicked
            });

            // Reset `liClicked` after a small delay so user interaction is registered
            $(document).on("click", function (event) {
                if (!$(event.target).closest("li").length) {
                    liClicked = false;
                }
            });

        }
    };

    // ** Reattach Behavior After AJAX Calls **
    $(document).ajaxComplete(function () {
        Drupal.behaviors.showMoreToggle.attach(document, drupalSettings);
    });

})(jQuery, Drupal, drupalSettings);
